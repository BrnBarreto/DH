package com.dh.dao;

import com.dh.model.Filial;

public interface IDao<F> {

    Filial salvar (Filial salvar);
}
