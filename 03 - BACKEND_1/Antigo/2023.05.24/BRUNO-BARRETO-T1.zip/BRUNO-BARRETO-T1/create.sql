create table if not exists filial
(Id int auto_increment primary key, nomeFilial varchar(255), numero varchar(10), cidade varchar(255), estado varchar(255) ehcincoEstrelas);