package service;

import model.Viagem;

public interface IFacadeTurismo {

    Viagem buscar(Viagem viagem);

}
